<?php
namespace Chetu\Np\Model\ResourceModel\Form;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
	protected $_idFieldName = 'employee_id';
	protected $_eventPrefix = 'ui_comp_form_collection';
	protected $_eventObject = 'form_collection';

	/**
	 * Define resource model
	 *
	 * @return void
	 */
	protected function _construct()
	{
		$this->_init('Chetu\Np\Model\Form', 'Chetu\Np\Model\ResourceModel\Form');
	}

}